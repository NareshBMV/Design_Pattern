﻿using System;

namespace SampleCore
{
    class Program
    {
    
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("Your Name :");
            String name = Console.ReadLine();

            Console.WriteLine("How many hours of sleep you rested last night :");
            int noOfSleep = int.Parse(Console.ReadLine());

            if (noOfSleep >= 8)
            {
                Console.WriteLine("You are well rested");
            }
            else
            {
                Console.WriteLine("You are not rested for betterment");
            }
            */
            //string myName = "Naresh" + "Babu";
            //Console.WriteLine("My Name is " + myName);

            //string strVariable = Console.ReadLine();

            //if(strVariable == "Naresh") {
            //    Console.WriteLine("Hi Naresh Welcome");
            //} else {
            //    Console.WriteLine("Please Come in " + strVariable);
            //}


            /*
            float data = float.Parse(Console.ReadLine());

            for (int i = 0; i < 10; i++) {
                if(i == 7) {
                    Console.WriteLine("Printing {0}",i);
                }
            }

            Console.WriteLine("Floating Value Entered : {0}",data);
			
            Console.WriteLine("Please enter 1 or 2 or 3");
            string enteredValue = Console.ReadLine();
            string message = (enteredValue == "1") ? "you won car" : "you won bicycle";
            Console.WriteLine("you entered : {0} and {1}", enteredValue, message);
            */

            /*
            string[] names = new string[] {"Naresh", "Bharath", "bala"};


            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            */



            /*

            //10th Video
            Console.WriteLine("The Name Game");

            Console.Write("What's your first name? ");
            string firstName = Console.ReadLine();

            Console.Write("What's your last name? ");
            string lastName = Console.ReadLine();

            Console.Write("In what city were you born?");
            string city = Console.ReadLine();


             
            //char[] firstNameArray = firstName.ToCharArray();
            //Array.Reverse(firstNameArray);

            //char[] lastNameArray = lastName.ToCharArray();
            //Array.Reverse(lastNameArray);

            //char[] cityArray = city.ToCharArray();
            //Array.Reverse(cityArray);

            //string result = "";

            //foreach (char item in firstNameArray)
            //{
            //    result += item;
            //}

            //result += " ";

            //foreach (char item in lastNameArray)
            //{
            //    result += item;
            //}

            //result += " ";

            //foreach (char item in cityArray)
            //{
            //    result += item;
            //}

            DisplayMessage(ReverseString(firstName), ReverseString(lastName), ReverseString(city));
            DisplayMessage(ReverseString(city));
            Console.ReadLine();


            */


            //11 video
            bool displayMenu = true;
            while(displayMenu)
            {
                displayMenu = MainMenu();
            }

        }


        private static bool MainMenu()
        {
            Console.Clear();
            Console.WriteLine("Select Options : ");
            Console.WriteLine("Option1 - Print Numbers");
            Console.WriteLine("Option2 - Guessing Numbers");
            Console.WriteLine("Option3 - Exit");

            string option = Console.ReadLine();

            if(option == "1")
            {
                PrintNumber();
                return true;
            } 
            else if(option == "2")
            {
                guessNumber();
                return true;
            }
            else if(option == "3")
            {
                return false;
            }
            else
            {
                return true;
            }
        }


        private static void PrintNumber()
        {
            Console.Clear();
            Console.WriteLine("Enter Count Number");
            int count = int.Parse(Console.ReadLine());
            int counter = 1;
            while(counter < count+1)
            {
                Console.Write(counter);
                Console.Write(" ");
                counter++;
            }
            Console.ReadLine();
        }

        private static void guessNumber()
        {
            Console.Clear();
            Console.WriteLine("Guessing Numbers");
            Random myRandom = new Random();
            int randomNumber = myRandom.Next(1, 11);
            int guess = 0;
            bool incorrect = true;

            do
            {
                Console.WriteLine("Guess a number");
                guess++;
                string guessed = Console.ReadLine();
                if (guessed == randomNumber.ToString())
                {
                    incorrect = false;
                }
                else
                Console.WriteLine("Wrong!!!!!");

            } while (incorrect);

            Console.WriteLine("You attempted {0} number of guesses", guess);

            Console.ReadLine();
        }



        /*

        //10th Video

        private static string ReverseString(String message)
        {
            char[] messageArray = message.ToCharArray();
            Array.Reverse(messageArray);
            return string.Concat(messageArray);
        }

        private static void DisplayMessage(string reversedFirstName, string reveresedLastName, string reversedCity)
        {
            Console.WriteLine("Results :");
            Console.Write(string.Format("{0} {1} {2}", 
                reversedFirstName, 
                reveresedLastName,
                reversedCity));
        }

        private static void DisplayMessage(string message)
        {
            Console.Write(string.Format("{0}", message));
        }

        */
    }
}















